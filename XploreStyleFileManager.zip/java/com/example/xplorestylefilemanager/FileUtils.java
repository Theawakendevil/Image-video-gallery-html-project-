package com.example.xplorestylefilemanager;

import java.io.*;

public class FileUtils {
    public static boolean copyFile(File src, File dst) {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean deleteFile(File file) {
        return file != null && file.exists() && file.delete();
    }
}